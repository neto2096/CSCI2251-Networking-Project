// Name: Ernesto Morales Carrasco
// Email: emoralescarras@cnm.edu
// Assignment: Networking Part 1
// Purpose: Entry point to start the server application for receiving and displaying matrices

public class ServerStart {
    // Main method to initialize and start the server
    public static void main(String[] args) {
        Server server = new Server();
        server.start();
    }
}